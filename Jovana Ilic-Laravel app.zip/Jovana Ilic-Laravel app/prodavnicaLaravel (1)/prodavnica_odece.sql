-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2021 at 01:01 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prodavnica_odece`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kategorijas`
--

CREATE TABLE `kategorijas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `naziv` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kategorijas`
--

INSERT INTO `kategorijas` (`id`, `naziv`) VALUES
(1, 'jakne'),
(2, 'majice');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_02_07_162029_create_pol', 1),
(5, '2021_02_07_162128_create_kategorija', 1),
(6, '2021_02_07_162149_create_proizvod', 1),
(7, '2021_02_07_162329_alter_proizvod', 2),
(8, '2021_02_07_162417_create_narudzbinia', 2),
(9, '2021_02_07_162548_create_stavkanarudzbine', 2);

-- --------------------------------------------------------

--
-- Table structure for table `narudzbinas`
--

CREATE TABLE `narudzbinas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prezime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `broj_telefona` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `narudzbinas`
--

INSERT INTO `narudzbinas` (`id`, `ime`, `prezime`, `adresa`, `broj_telefona`) VALUES
(3, 'Marko', 'Nedic', 'Novi Sad', '061/5254-312'),
(7, 'Milan', 'Stanimirovic', 'Novi Beograd', '064/578-9012');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pols`
--

CREATE TABLE `pols` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `naziv` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pols`
--

INSERT INTO `pols` (`id`, `naziv`) VALUES
(1, 'zenski'),
(2, 'muski');

-- --------------------------------------------------------

--
-- Table structure for table `proizvods`
--

CREATE TABLE `proizvods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `naziv` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slika` varchar(1255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `opis` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cena` int(11) NOT NULL,
  `velicina` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategorija_id` bigint(20) UNSIGNED NOT NULL,
  `pol_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `proizvods`
--

INSERT INTO `proizvods` (`id`, `naziv`, `slika`, `opis`, `cena`, `velicina`, `kategorija_id`, `pol_id`) VALUES
(1, 'ZENSKA VODOOTPORNA PROŠIVENA JAKNA', 'https://static.zara.net/photos///2021/V/0/1/p/4341/715/712/2/w/1280/4341715712_1_1_1.jpg?ts=1612432724155', 'JAKNA SA VISOKOM KRAGNOM I KAPULJAČOM SA PRILAGODLJIVIM UČKURIMA I STOPEROM. DUGI RUKAVI SA', 4990, 'XS\r\nS\r\nM\r\nL\r\nXL\r\nXXL', 1, 1),
(2, 'ZENSKA MAJICA LOVE ™ ROCKY & BUTKUS', 'https://static.zara.net/photos///2021/V/0/1/p/4644/352/620/3/w/1280/4644352620_1_1_1.jpg?ts=1612432207398', 'MAJICA SA OKRUGLIM IZREZOM, KRATKIM RUKAVIMA I PRINTOM ™ ROCKY & BUTKUS © MGM SA PREDNJE', 2290, 'S\r\nM\r\nL', 2, 1),
(3, 'JAKNA OD TEHNIČKE TKANINE SA KAPULJAČOM', 'https://static.zara.net/photos///2021/V/0/2/p/8281/407/434/2/w/1280/8281407434_1_1_1.jpg?ts=1608711350871', 'JAKNA SA PRILAGODLJIVOM KAPULJAČOM I DUGIM RUKAVIMA SA ELASTIČNIM MANŽETNAMA. NAŠIVENI', 6590, 'S\r\nM\r\nL\r\nXL\r\nXXL', 1, 2),
(4, 'MUSKA MAJICA MIKI MAUS © DIZNI', 'https://static.zara.net/photos///2021/V/0/2/p/0722/411/251/2/w/1280/0722411251_1_1_1.jpg?ts=1611075390068', 'ŠIROKA MAJICA SA OKRUGLIM IZREZOM I KRATKIM RUKAVIMA. KONTRASTNI DEZEN SLOGANA SA PREDNJE STRANE I', 2590, 'S\r\nM\r\nL\r\nXL', 2, 2),
(5, 'REPLAY Black Biker Jacket with Pockets MEN', 'https://lh3.googleusercontent.com/proxy/tVU2xtnM60h5E2KkBsodnvH9DUpAFdxS-LiafO0TIfHy_MBKjNFZzo0xnamI3tgNu-6aWwql_MRKliqGhX5yJf-AviDXHVtw-01k-wb-OwQ3pghcXFhbjC3MvBwavrdCKeFWHIfyr67cbPwNYluF4g45C0oMJb7aWVfnsjvXNf2MkSmNSCtd94GL2fqL0kxtpliynVJzZ8kJSLHEpatavjZJr0ESPQeoU6m_Tpc', 'Crna muska kozna jakna marke replay. ', 8999, 'XL XS L M', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `stavkanarudzbines`
--

CREATE TABLE `stavkanarudzbines` (
  `narudzbina_id` bigint(20) UNSIGNED NOT NULL,
  `proizvod_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stavkanarudzbines`
--

INSERT INTO `stavkanarudzbines` (`narudzbina_id`, `proizvod_id`) VALUES
(3, 1),
(7, 3),
(7, 3),
(7, 4),
(7, 3),
(7, 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `kategorijas`
--
ALTER TABLE `kategorijas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `narudzbinas`
--
ALTER TABLE `narudzbinas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `pols`
--
ALTER TABLE `pols`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `proizvods`
--
ALTER TABLE `proizvods`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proizvods_kategorija_id_foreign` (`kategorija_id`),
  ADD KEY `proizvods_pol_id_foreign` (`pol_id`);

--
-- Indexes for table `stavkanarudzbines`
--
ALTER TABLE `stavkanarudzbines`
  ADD KEY `stavkanarudzbines_narudzbina_id_foreign` (`narudzbina_id`),
  ADD KEY `stavkanarudzbines_proizvod_id_foreign` (`proizvod_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kategorijas`
--
ALTER TABLE `kategorijas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `narudzbinas`
--
ALTER TABLE `narudzbinas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pols`
--
ALTER TABLE `pols`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `proizvods`
--
ALTER TABLE `proizvods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `proizvods`
--
ALTER TABLE `proizvods`
  ADD CONSTRAINT `proizvods_kategorija_id_foreign` FOREIGN KEY (`kategorija_id`) REFERENCES `kategorijas` (`id`),
  ADD CONSTRAINT `proizvods_pol_id_foreign` FOREIGN KEY (`pol_id`) REFERENCES `pols` (`id`);

--
-- Constraints for table `stavkanarudzbines`
--
ALTER TABLE `stavkanarudzbines`
  ADD CONSTRAINT `stavkanarudzbines_narudzbina_id_foreign` FOREIGN KEY (`narudzbina_id`) REFERENCES `narudzbinas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `stavkanarudzbines_proizvod_id_foreign` FOREIGN KEY (`proizvod_id`) REFERENCES `proizvods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
