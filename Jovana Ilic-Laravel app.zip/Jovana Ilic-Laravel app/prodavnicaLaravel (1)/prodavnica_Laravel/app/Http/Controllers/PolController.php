<?php

namespace App\Http\Controllers;

use App\Models\Kategorija;
use App\Models\Pol;
use App\Models\Proizvod;
use Illuminate\Http\Request;

class PolController extends Controller
{
    public function all(){
        $polovi=Pol::all();
        return view('pocetna', [
            'polovi'=>$polovi
        ]);

    }
    public function view($id){
        $pol=Pol::find($id);
        $kategorije= Kategorija::all();
        $proizvodi=Proizvod::all();
        $odeca=[];
        foreach ($proizvodi as $proizvod) {
            if ($proizvod->pol_id == $pol->id) {
                $odeca[count($odeca)] = $proizvod;
            }
        }
        $pol->proizvodi=$odeca;
        $pol->kategorije=$kategorije;

        return view('pol',['pol'=>$pol]);

    }
}
