<?php

namespace App\Http\Controllers;

use App\Models\Kategorija;
use App\Models\Pol;
use App\Models\Proizvod;
use Illuminate\Http\Request;

class KategorijaController extends Controller
{
    public function view($id){

        $pieces = explode("/", url()->current());
        $kateogrija= Kategorija::findOrFail($pieces[count($pieces)-1]);
        $pol=Pol::findOrFail($pieces[count($pieces)-2]);
        $proizvodi=Proizvod::all();
        $odeca=[];
        foreach ($proizvodi as $proizvod){
            if($proizvod->pol_id==$pol->id && $proizvod->kategorija_id==$kateogrija->id) {
                $odeca[count($odeca)] = $proizvod;
            }
        }
        $kateogrija->proizvodi=$odeca;
        return view('kategorije',['kategorija'=>$kateogrija]);

    }
    public function getAll(){
        $kategorije=Kategorija::all();
        $proizvodi=Proizvod::all();
        foreach ($kategorije as $kategorija) {
            $odeca=[];
            foreach ($proizvodi as $proizvod) {
                if ($proizvod->kategorija_id == $kategorija->id){
                    $odeca[count($odeca)]=$proizvod;
                }
            }
            $kategorija->filmovi=$odeca;
        }

        return response()->json($kategorije,200);
    }
    public function getById($id){
        $kategorija=Kategorija::find($id);
        $proizvodi=Proizvod::all();
        if(is_null($kategorija)){
            return response()->json(["message"=>"Ne postoji kategorija"],404);
        }
        $odeca=[];
        foreach ($proizvodi as $proizvod) {
            if ($proizvod->kategorija_id == $kategorija->id){
                $odeca[count($odeca)]=$proizvod;
            }
        }
        $kategorija->filmovi=$odeca;
        return response()->json($kategorija,200);
    }
}
