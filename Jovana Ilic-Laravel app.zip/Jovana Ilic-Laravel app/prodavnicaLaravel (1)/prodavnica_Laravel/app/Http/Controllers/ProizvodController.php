<?php

namespace App\Http\Controllers;

use App\Models\Proizvod;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ProizvodController extends Controller
{
    public function view($id){

        $pieces = explode("/", url()->current());
        $proizvod= Proizvod::findOrFail($pieces[count($pieces)-1]);
        return view('proizvod',['proizvod'=>$proizvod]);

    }
    public function getAll(){

        return response()->json(Proizvod::all(),200);
    }
    public function getById($id){
        $proizvod=Proizvod::find($id);
        if(is_null($proizvod)){
            return response()->json(["message"=>"Nema datog proizvoda!"],404);
        }
        return response()->json($proizvod,200);
    }
    public function save(Request $request){

        $validator = Validator::make($request->all(), [
            'naziv'=>'required|min:2',
            'opis'=>'required|min:2',
            'slika'=>'required|min:2',
            'cena'=>'required|min:2',
            'velicina'=>'required|min:2',
            'kategorija_id'=>'required',
            'pol_id'=>'required',

        ]);

        if ($validator->fails()) {
            return response()->json(["message"=>"Sva polja su obavezna"],400);
        }
        $proizvod= Proizvod::create($request->all());
        return response()->json($proizvod, 201);
    }
    public function delete(Request $request, $id){
        $proizvod=Proizvod::find($id);

        if(is_null($proizvod)){
            return response()->json(["message"=>"Nema datog proizvoda!"],404);
        }
        $proizvod->delete();
        return response()->json(null,204);
    }
}
