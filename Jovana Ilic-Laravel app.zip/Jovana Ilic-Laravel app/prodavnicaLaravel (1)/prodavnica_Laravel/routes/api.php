<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route:: get('kategorije', 'App\Http\Controllers\KategorijaController@getAll');
Route::get('kategorije/{id}', 'App\Http\Controllers\KategorijaController@getById');
Route::get('proizvodi', 'App\Http\Controllers\ProizvodController@getAll');
Route::get('proizvodi/{id}', 'App\Http\Controllers\ProizvodController@getById');
Route::post('proizvodi', 'App\Http\Controllers\ProizvodController@save');
Route::delete('proizvodi/{id}', 'App\Http\Controllers\ProizvodController@delete');
