<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProizvodTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('proizvods')->insert(
            [
                ['naziv' => 'ZENSKA  JAKNA', 'slika' => 'https://static.zara.net/photos///2021/I/0/1/p/4341/724/800/2/w/1920/4341724800_6_1_1.jpg?ts=1632393941204', 'opis' => 'JAKNA SA VISOKOM KRAGNOM DUGI RUKAVI ', 'cena' => 3217, 'velicina' => 'X XL', 'kateogrija_id' => 1, 'pol_id' => 1],
                ['naziv' => 'ZENSKA MAJICA ', 'slika' => 'https://www.estaonline.org.uk/wp-content/uploads/2021/08/womens-t-shirts-zara-natacha-paschal-striped-t-shirt-white-navy_4.jpg', 'opis' => 'MAJICA SA PRUGAMA', 'cena' => 1327, 'velicina' => 'X XL', 'kateogrija_id' => 1, 'pol_id' => 1],
                ['naziv' => 'JAKNA OD TEHNIČKE TKANINE SA KAPULJAČOM', 'slika' => 'https://www.terranovastyle.com/rs_sr/pub/media/catalog/product/c/o/colour-block-technical-jacket-16-sab0051177001s105-kw-capospalla-kw-nero_4_1.jpg', 'opis' => 'JAKNA SA VISOKOM KRAGNOM I KAPULJAČOM SA PRILAGODLJIVIM UČKURIMA I STOPEROM. DUGI RUKAVI SA', 'cena' => 2117, 'velicina' => 'X XL', 'kateogrija_id' => 1, 'pol_id' => 1],
                ['naziv' => 'MUSKA MAJICA ', 'slika' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTpfZsXoFLqJDoDfyWi7ho0bdseuIgaN3yPXw&usqp=CAU', 'opis' => 'majica SA VISOKOM KRAGNOM ', 'cena' => 431217, 'velicina' => 'X XL', 'kateogrija_id' => 1, 'pol_id' => 1],
                ['naziv' => 'REPLAY Black Biker Jacket with Pockets MEN', 'slika' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSS48pxLiq0icH2gR3OV8XX0fy0X57y80tEDA&usqp=CAU', 'opis' => 'JAKNA SA VISOKOM KRAGNOM I KAPULJAČOM  DUGI RUKAVI SA', 'cena' => 1327, 'velicina' => 'X XL', 'kateogrija_id' => 1, 'pol_id' => 1]
            ]
        );
    }
}
