<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterProizvod extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    /*dodata su dva spoljna kljuca ka polu i kategoriji*/
    public function up()
    {
        Schema::table('proizvods', function (Blueprint $table) {
            $table->foreignId('kategorija_id')->constrained('kategorijas');
            $table->foreignId('pol_id')->constrained('pols');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
