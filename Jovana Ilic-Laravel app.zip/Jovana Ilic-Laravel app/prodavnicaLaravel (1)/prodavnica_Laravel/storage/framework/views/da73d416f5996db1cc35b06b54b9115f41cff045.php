<p>dsadsaf</p>
<?php /**PATH C:\Users\Windows HD\Desktop 5\laravelProj\studentsdata\resources\views/welcome.blade.php ENDPATH**/ ?>