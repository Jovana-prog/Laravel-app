<?php $__env->startSection('title','Kategorije'); ?>

<style>
  html {
  font-size: 62.5%;
}

.product-list {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  width: 460px;
  margin: 40px auto;
}

.product-item {
  position: relative;
  width: 135px;
  height: 280px;
  margin-bottom: 23px;
  box-sizing: border-box;
}
.product-item:hover .product-card {
  z-index: 2;
}
.product-item:hover .product-extra-card {
  opacity: 1;
  visibility: visible;
  box-shadow: 0px 5px 30px -5px rgba(0, 0, 0, 0.5);
}
.product-item:hover .product-add-to-catr {
  background: #eb5c3e;
}
.product-item:hover .rating-item {
  fill: #eb5c3e;
}

.product-card {
  height: 100%;
  position: relative;
  transition: z-index 0.3s 0.3s;
}

.product-image {
  margin-bottom: 12px;
  text-align: center;
}
.product-image img {
  display: inline-block;
  max-width: 135px;
  max-height: 135px;
}

.product-title {
  margin: 0 0 8px 0;
  font-size: 1.3rem;
  line-height: 1.6rem;
  text-align: center;
  font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
  min-height: 50px;
}

.product-shop-elements {
  overflow: hidden;
  margin-bottom: 18px;
}

.product-price {
  float: left;
  font-size: 1.2rem;
  line-height: 1.6rem;
  font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
  font-weight: bold;
  margin-top: 4px;
  letter-spacing: -0.8px;
}
.product-price span {
  font-size: 1.8rem;
  line-height: 1.6rem;
}

.product-add-to-catr {
  float: right;
  padding: 7px;
  font-size: 1.2rem;
  line-height: 1.6rem;
  color: #fff;
  background: #3a3a3a;
  font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
  margin-right: 2px;
  transition: background 0.3s 0s;
  cursor: pointer;
}

.product-rating-list {
  position: relative;
  overflow: hidden;
  text-align: center;
  font-size: 0;
  line-height: 0;
}
.product-rating-list:before {
  content: "";
  position: absolute;
  left: 0;
  top: 50%;
  width: 100%;
  height: 1px;
  background: #efefef;
}

.rating-element-wrapper {
  display: inline-block;
  background: #fff;
  position: relative;
  z-index: 1;
  padding: 0 7px;
}

.rating-item {
  width: 12px;
  height: 11px;
  display: inline-block;
  fill: #3a3a3a;
  margin-right: 3px;
  transition: fill 0.3s 0s;
}
.rating-item:last-child {
  margin-right: 0;
}

.product-description {
  font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
  font-size: 1.1rem;
  line-height: 1.4rem;
  padding: 0 9px 9px 9px;
  background: #fff;
}

.product-extra-card {
  position: absolute;
  z-index: 1;
  top: -12px;
  left: -11px;
  right: -14px;
  padding: 290px 0 0 0;
  box-sizing: border-box;
  border: 3px solid #eb5c3e;
  opacity: 0;
  visibility: hidden;
  transition: opacity 0.3s 0s, visibility 0.3s 0s;
}

@media (max-width: 1024px) {
  .product-item {
    height: auto;
  }

  .product-card {
    height: auto;
  }

  .product-rating-list {
    margin-bottom: 15px;
  }

  .product-extra-card {
    position: relative;
    padding-top: 0;
    opacity: 1;
    visibility: visible;
    border: 0;
    top: 0;
    left: auto;
    right: auto;
  }
}
@media (max-width: 800px) {
  .product-item {
    max-width: 250px;
    width: auto;
    margin: 0 auto;
  }
}

ul {
  width: 620px;
  margin: 0;
}
ul li {
  float: left;
  list-style: none;
  margin-right: 10px;
  position: relative;
}
ul li a {
  font: 700 15px Open Sans;
  text-transform: uppercase;
  position: relative;
  color: #333333;
  text-decoration: none;
  border: 3px solid #000000;
  letter-spacing: 1px;
  padding: 10px 15px 10px 25px;
  display: block;
  width: 150px;
  z-index: 5000;
}

.animate {
  width: 100%;
  transition: 0.3s ease;
}
</style>

<?php $__env->startSection('content'); ?>

    <h2 style="margin: 0px 45vw; margin-top: 30px; font-size: 20px; background-color: beige; padding: 10px 20px;"><?php echo e($kategorija->naziv); ?></h2>
    <div class="product-list" >
    <?php $__currentLoopData = $kategorija->proizvodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proizvod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="product-item" style="margin-top: 15px;">
         <div class="product-card">
              <div class="product-image">
                   <img src="<?php echo e($proizvod->slika); ?>" alt="" />
              </div>
              <div class="product-title"><a style="color: black; text-decoration: none; font-size: 12px; cursor: pointer;" href="<?php echo e($proizvod->kategorija_id); ?>/<?php echo e($proizvod->id); ?>"><?php echo e($proizvod->naziv); ?></a></div>
              <div class="product-shop-elements">
                   <div class="product-price"><span><?php echo e($proizvod->cena); ?></span>.00 RSD</div>

              </div>
         </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ITEH2021\D O M A C I\Laravel\Laravel\prodavnicaLaravel (1)\laravel\resources\views/kategorije.blade.php ENDPATH**/ ?>