<?php $__env->startSection('title','Proizvodi'); ?>

<style>
  * {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
*:before, *:after {
  box-sizing: border-box;
}

:root {
  font-size: 10px;
}

body {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-color: #f7f9fa;
  font-family: "Poppins", sans-serif;
}

.nav {
  display: flex;
  flex-direction: column;
  font-size: 1.8em;
  max-width: 600px;
  width: 100%;
  padding: 1rem;
}
.nav__item {
  width: 100%;
  flex-grow: 1;
  display: flex;
  align-items: center;
  text-decoration: none;
  margin: 0 0 1em;
  border-radius: 1em;
  min-height: 150px;
  background: #eef0f1;
}
.nav__item:hover, .nav__item:focus {
  background: #febadb;
}
.nav__item:hover .nav__text, .nav__item:focus .nav__text {
  color: #340119;
}
.nav__item:hover .nav__image, .nav__item:focus .nav__image {
  transform: translate3d(-1em, 0, 0);
}
.nav__item--svg path {
  fill: #8e99a4;
}
.nav__item--svg:hover path, .nav__item--svg:focus path {
  fill: #340119;
}
.nav__text {
  color: #8e99a4;
  padding: 1em;
  font-size: 7vmin;
  font-weight: 900;
  font-style: italic;
}
@media (min-width: 556px) {
  .nav__text {
    font-size: 3rem;
  }
}
.nav__image {
  display: block;
  max-width: 110px;
  width: 100%;
  height: auto;
  margin: 0.5em 0.5em 0 auto;
  transition: transform 0.4s ease;
}
</style>

<?php $__env->startSection('content'); ?>

    <nav class="nav">

   <a href="/2" class="nav__item">
     <span class="nav__text">Men</span>
     <img src="https://freepngimg.com/thumb/man/22723-4-man-transparent-background.png" class="nav__image" alt="Woman in a summer dress" />
   </a>
   <a href="/1" class="nav__item">
     <span class="nav__text">Women</span>
     <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/538758/tops.png" class="nav__image" alt="Woman with arms crossed in a top and jeans" />
   </a>

 </nav>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\saradojicic\Desktop\ITEH\Laravel\prodavnicaLaravel (1)\laravel\resources\views/pocetna.blade.php ENDPATH**/ ?>