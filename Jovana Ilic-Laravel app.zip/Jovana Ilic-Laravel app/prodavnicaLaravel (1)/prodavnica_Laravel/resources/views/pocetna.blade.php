@extends('master')

@section('title','Proizvodi')

<style>
  * {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
*:before, *:after {
  box-sizing: border-box;
}

:root {
  font-size: 20px;
}

body {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-color: #CD5C5C;
  font-family: "Poppins", sans-serif;
}

.nav {
  display: flex;
  flex-direction: column;
  font-size: 1.8em;
  max-width: 600px;
  width: 100%;
  padding: 1rem;
}
.nav__item {
  width: 100%;
  flex-grow: 1;
  display: flex;
  align-items: center;
  text-decoration: none;
  margin: 0 0 1em;
  border-radius: 1em;
  min-height: 100px;
  background: #CD5C5C;
}
.nav__item:hover, .nav__item:focus {
  background: #F0E68C;
}
.nav__item:hover .nav__text, .nav__item:focus .nav__text {
  color: #D3D3D3;
}
.nav__item:hover .nav__image, .nav__item:focus .nav__image {
  transform: translate3d(-1em, 0, 0);
}
.nav__item--svg path {
  fill: #8e99a4;
}
.nav__item--svg:hover path, .nav__item--svg:focus path {
  fill: #340119;
}
.nav__text {
  color: #8e99a4;
  padding: 1em;
  font-size: 7vmin;
  font-weight: 900;
  font-style: italic;
}
@media (min-width: 556px) {
  .nav__text {
    font-size: 3rem;
  }
}
.nav__image {
  display: block;
  max-width: 110px;
  width: 100%;
  height: auto;
  margin: 0.5em 0.5em 0 auto;
  transition: transform 0.4s ease;
}
</style>

@section('content')

    <nav class="nav">

   <a href="/2" class="nav__item">
     <span class="nav__text">Muškarci</span>
     <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBERERgSERUSGBgRGBERGBERGBEYERIRGBgZGhgYGBgcIS4lHB4rHxgYJkYmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHhISGTYlJCM0NDQ0NDQ0NDQ0NTQ0NDQ0NDQ6NDQ2NDQ0NDQ0NDQ0NDQ0NDQxNDExMTQ0NDQ0MTE0Mf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAAAAgEDBAYHBQj/xAA9EAACAQMCAwYDBQcEAgMBAAABAgADERIEIQUxQQYiUWFxgRORoTJSscHwBxQjQmJy0YKS4fGiwjNDshX/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAQIDBAX/xAAgEQEBAQEAAwACAwEAAAAAAAAAAQIRAxIhMUETYXFR/9oADAMBAAIRAxEAPwD5wWGMsCycZoV4yMZbjJxgUYRSk04xSsDMacUpNRSKUlGUpEKTUUiMkDKUkFJpKRSkDPjIxmjGRhAoxhjLcIYQKsZFpdjIxgVWhaWWiM6jmRt06j2kC4wxjswHPa/LIFSfQGCMG+yQfQg2gJaRjLsYYwKcZNpbhDCBXaSBHCycYChZIWMFjAQFCxgIwEYCAlpNo9oYwFxhHtCB9AJJxmgJJwlGbGGM04ScIGXGGM1YRSkDKUilJrKRDTgZSkRkmspFKQMhSKUmo04pSBlxkFJpKSCkDNhDCaCkjCBnxlNdlRSzEBVFyT0E2FZyHazWkv8ABH2UxZvEuRsD5AH6yWjJr+NvUYhCVTkFB7zebH8hMSa2pt3ytjtjsB+AmMC8+jo9A7kYozk22F8WHXluJi/2s7+n2OGcRrB8mrG3MmoDiR/eMh8xbxtLOL6mqrfEUJtY5U7BsPFk5Ov9S2E1aTs3r3t8PTEHmGDYt1tuTa/IWIINuQmt+xWswyFHHc9zfa473d5DrutvTwntHT00o4VrRXS+wZbBgOW/IjyP5GbsZ83QcKq6SphWVlNUEKLbbXNz4dfrPr4Teb2OepZeVXjIKy20LTSKsZOMstJxgVhYwWPjJxkFeMYCPjJCwEtJxj4ycZQloSy0IH3BTgKc0BJISBn+HD4c1YQwgZfhyDTmvCRhAyGnENObSkg04GE04jU5uKRGSBhKRDTm5qcQ04GIpFKTYacUpAyFJBSaSkUpAysk8347/wDO9wQS7mx6WNh9AD7z09knn/arTlNS9+T4OPAgi34q0zok659BvPQOy1QgIoSwFyGt1PPnvOO4XSQ1Aan2RvboT0vO01HB9VqVWpoyDiLFEYI/t/icPJe/Ho8OefXqHCdSoUFzaxA+c+xWOWynbneeInTcZpWC/vRJt3QtSw9chid+vLznT6uvxDS8NXVNULVPiLTNOykAMbWuOZvac+cnHb83v4ae3g/iaZhe4qOnd6qUNwfLlPjFZTpeIavVd3VKv8J8xdbOrlSNiOYsx+QmzGejxTmXl8t7pRjDGXYwxnVzU4wxl2MMYFWMkLLMZIWBXjDGWYycYFYWTjLLSQsCvGEtxkQOjCRgktwjBIRSEhhL8ZOEgz4QKTRhApAzlIpSaSkUpAzFIpSacJBSUZCkU05rKRSkDGUiGnNhSKUgYykQpNhSKUhWI05xvbuiVNKoACLOjeY2ZR5cj7zvGSfK7QcOGo0zpa5tkv8Acu4/CZv4Hl4QBbjxPysCPxnWdiuIVqb4i+JtzPKcqGAZkPlb1G369J9PgnETTdQ3oD5+c4bnz47+HUl+vXeOcU+FpA7tipZFLtcgFj1A5y3g+v0+o02KVKb98kgEG4Cm5xO85GpxKtXVtJU09OsjqpCrXoo/kwzsQwPh1EOzWlTQ5L8PUh6wxzqqmCILkKCp8eu1/Acpzk7OvTez9fH1eJujOFRVCoMBiAATck2AmLGaMYYz2ZnrOPDrXtbWbCGE0YSMZWVGMjGaMYpWBTjJCyy0LQK8YYy3GTjAqxk4yy0m0CvGEtxhA6jCSEloWMFkRVhDCXYycYFOMMZdjDGBnKRSk0lYhSBnKSCk0lIpSBmKxSs0FIhWBnKxSs0FYpWBnKRSk0FYpWUZWSfB7WcW/dKF1sXqHBQei/zPbqALe7LPqcb4vR0iZVDdjfCkts3PkOg8ztPI+N62rqajV6h+0bBASVpr0VQeQ29z6yUYKz3a4j0q24J3sQbHrbpKMf10/wCIyrbnOdjeb9dzpW4XqVVqj16LqLXR1A/8lP0InScL0FNBnTq1aoYDF6xuSPEeXT5zz3s2KQqitXIFOicsObVH/lRR18fDlO17K8eSsoouQrqTY/y1LktYeDb8pnGfv+Ou/Jbnn/X3cIpSaSkgpO7gzYSMZoKRSsDPjIKy8rIKwKMZGMvxkYwKsYYy7GRjAqxk2j4ycYFdoSy0IHWBYwEkCMBIhbQtHtDGAlpOMa0LQEtIKyy0i0CvGKVl2MjGBnKxWWaSsrKwMxWV1CFBZiABzZiAB6k8pznbbtM+hanTpKheoGdmcEhUBsAFBG5N/wDb5zzviHEq2pbKu7P1UMe4v9qjZfYSj0biXa7SUdkf4rfdpWKe7/Z+V5x/FO12rqghG+GvLCls9vNzvf0tPgA+kSrUxANtr97xA8Y4JdzUJLMxJ5s98j633MpZQbr0bb36fUS5je3h49LStxblA+fUpMvTkb+n+R5y+hQeojMqm1IZM1tlQ9fmPqZuxuAfH9EfrxlZL06bohGFXEshva6nukeYJ59N/GYsalnfqqjpy4GNgLbE/aIltLuuyjlirD2Nr/hLggXl5Drt6Spk76eYZfpcfhNRl97QdpNVSsMw6j+WqMrD+77X1nQ6PtfQcfxUdD4gZp9O99JwvMyb+XvKPUtJxGhW2pVKbH7oIz/2nf6TSVnk1r72+nWfd4Jx7UU61Om7s6Oy0yr7lQxAuG57eZjg7orFKy8rFKwKcZGMuKxSsCq0CsstC0KqtC0e0m0Cu0I9oQOtAk2jgSQJEKBC0fGFoCWhaPaFoFdpFpZaFoFdoWllpFoFREUrLiIjkKCWNgASSeQA5mB49+07UK+uCKQfg0kRrfyuWdyD/pZT7zlEc4nl3fwO3+JbxLVmtXqVrk/FqVHufusxI+lh7SmlY36X7vreIHSrfa80F7/oT5iOQwHr9BNCVzfmevXyllCk4Gx+yev3P+JoIFvPxMQPfr/iQnd2PI8vLyP6/wCQso9R7yx0yUjyMQG5lwElA1jY+MqrDvIf6v8A1aWBe6LdLC3ptKaxuU/u+XdaUW2tz9vf9GQvlJbbb38jDA+HOUSBb3/CQjkEWJBUlh5EcjEe9uR2iIxysPMX8Nx/iB6vwTX/ALzp0qkWY3VwOQqKbNbyPP3E3EThuw3EAlZqDHaqLr4fFX/K3/2id4RIKrRSJbaKRArtAiPaRaAloWk2haFJaEaEDsQskLHxjBZEV2haW4wtAqKxSJcVikQKrQtLLSLQEtC0stItArInxO19XDh+pa9v4VRb+bjAD1OVvefdInBftY1uGlp0AbfHcuw6slMXt/vZD7QPJL9YLUQ7E2PRh+YiuL+UFpf2n1gU6nZ7+NjtuPaSG3hrrXFtuYte8rQ3AkF9Oob85oR8hY3sfMzFaxl1J7H/AKllGhXO6nmOv3h4/wDE0odr9OXvMtYFhktsk3H9Q6iNpq4cX+Y8JRoQmx8i31JP5ymqhyQlSA2RBIIDAbbE8/COjgFrkbkWubcwP8GdRwV0qaYafXI4RWLUK7h1C5cwHty+h28Jz1r1+108fju7ZPy5i5ksTOi4p2S1NLv0v4qc7pb4gXzTr6rf0E5qo+3WbzqWdjOs3N5YUtEVzkfy3b22klj4zPQqgk3JFidxyt6S9ZbKOqKuGUsrKVdS3RlIIPzE9f0GqFailUC3xER7fdJG49jce08fNmHMHz2B+k7L9nurIL0GY2sKiKxJsQbPj81NvK/jFHbWikR7SCIFdpFo5Ei0CsiRHIiwFtCTaEDtgI1pIEm0iotC0a0LQEIikSwiRaEJjICyy0LQKysgiW2ikQKiJ4X254t+9a6obkpSJoIB9kKhIZh6tkb+FvCe4a2qKdN6hIUIj1CxIAUKpNyenKfmx7nlt4k8yfOAzIbbDzlbI/UgQyC/zn0ttLPjX6H1lGPX/wAtzfnMyGfU1WgqPTNYKfhoyUy/QO4ZlB9lPzHjPkkWMzRa7EG/QyQ4kK4IsZDr4QPo6dx4fUyioTSqXXk3Tw8bSnT1LHebNQodNuexHrb1mv0KtdjtvY90geJFwfSdZwrXcRQK1jUVrHKmyMCN73F/MbW6Th3N1Xyuvy3H4z7fZXW6ilXH7vY82ZGZFDAc/tEC84+Sdjv4bzXOvXOF6n4tNT8JqZt3ha1m6mw2I85zHa/s6Hyr6cAuLs9NQp+J4uo+94jr687/AP8Aqo7rmQ2e24ZQH6Dfuk8xsZ9nRaxOVrdBcWF/DyPlOE1c3serWZv5XkRqC17C3Pp+U+dp6gVrnkec9M7RdlKDo9WiSj2dzT/+tzYk2+6fTbynmv7qw9PEWv8AKenOvb7Hh3i5vK2KrDdMCD+us16HW1KNVKqjvU2DDz6EHyIJHoTPlYqvNnv4DnNS1HNrMPUd42HntN9Ye0cP1qaimtWmbq/Q81bqrDoRNBnm3YniT0dUKR3TU93zWooJVrctwCPceE9JMoUyIxkGAhkRjFgLCEIHdSYQkUSYQhBItGkQItC0aEBbSCI9pFoHJftJrNT4ZVx2NQ0qZP8AQzrkPdQR7zwtiOt/QT2n9rNXHhwXpUrU1Poqu/4oJ4szjnb3MAuedlUf1Hf6Rajvb7S2PUDb0ve8Zal+i+FyN4y0U6iwJAOOxt1t0Bgeo9ieELquCvRqAL+8vW74AN2Uqqv52ZLf6Z49raDI5RxZlJVl+6wNiPY3n6G7N8W4fVpJR0boBTQKtBu7VVV8VO5PUkXuSTPG/wBo2mFPidcLazsKoItb+Ioc/wDkWijllEdT0MRTvLVYEWMylK9MrvNWlq32iAbWM18K4PWrt3BZQd6jA4jyH3j5fhFvPq5l1eRhrpYsPHvD85ZwzUpTcMy3ty3IAPibTvafZfRrTyrmoCoN2ZwFN/QW5TAdBwcMQwYAdVdyT9Zzu8349OfDvP34wpxam4KtSyBvydVa3o17/OauH8V/kY1CB9ksUFRR4XLWe3nY+s+BxenQaqTpAUp2UBWLkkgbm5uRefLZGHO/4iP4/ifzWV6TruM1E0zn4bFQjLnUemOYIFkVmJ3I5kThlvMdf4iqA2QDqHAvsykkA29QflLi5msZ9XPy79uLww62/GNkOYAvMmUPi/WdOubfp9U9N1qIbOhDK39QPXx/5nseh1HxaSVLW+IiPj4ZKDb6zwypVNr/AHSPkQZ7rpKQSmiDkiIg9FUD8pQ5kGSZBgK0UxmiGBEIXhA7uTIgJFTCEIRMJEmASZEmAQtCEDiP2s0cuHBvuVqbH3V1/wDYTw6p+vKfpXtFwpdZpKmnYgfEXuseS1FIZGPkGUe15+eOJ8OqUKjUqqMjpsUYbjzHiPMbGSj5waOKsV6Z/wC5Udo6NiVvpvtzvK0qAAgW9NrTIGkky9FrKp5gevKQyL+fWVgw3PLrt7mB1fBezCVaSVajsM+8Ka8ynS7dL+nIifc1FH4CKqr3UsAyA93ysOXrPmabi9enTUGipRFVQxyTHEW3O4li8fDjuOqk37rNTyB5EbneeTV1p7sTGZyfl9qnq1q0ijoHUrZlNjceY5+8+XqeEcNwLgMh3BAd7pfqASepHOZRxJXOLFCy95WR1yVvLE8/Ka11NF6TlERq1Gm5apUCYqMTzOIsx3AAF/a5jPY1rlnbJXGstibb2J3ta46GI6ncWPWVXt9JN563zy6usHSkPuK9P2Ls4PzqEexgykn9flMtVbG19uYnsfAeF8O1mlp1xpqF3UBwEAxqLs49MgfYiQeQsCOfhf8A7hSTMFeR5g/lPbanZfh7Cx01Hb7q4n5rYxU7MaBeWmo/6ly//V5eDy7stwZ9ZqAhBwTFqrdFQH7Pq1rfM9J7GBK9Lo6VFcKKIik5FUVVBPibcz5ywyhTIMZjKyYENEMljEJgTeEXKEDvLyQYQkBeF4QgTeF4QgTeF4QgTeF4QgF5g4rwnTatMdTSRwL2zG6eaMO8p9CIQgef8b/ZaDdtDUA5n4Ne/wAlcfmPeeacY4PW0tQ0q6YOvNckbb1UkQhIPkOtpUWhCQAqGOlQg5DmNxfleEIF9PiVRTcW3uNtpB1jMQdrjyG/r4whM8jXtWpNUrjFiV5bgm1/QCfcqarS/ujLWqO7srCnTRWREdBsW++b/eJFuUITPPsds6vrXNsfT5CRn+rCEJ2edJNzfrPQP2XauwrUN+a1x4dFb32WEIHfExSYQlCExCZEICs0RjCEBGMrLQhATKEIQP/Z"class="nav__image" alt="Woman in a summer dress" />
   </a>
   <a href="/1" class="nav__item">
     <span class="nav__text">Žene</span>
     <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS_RY2s4ePMzs7jrX-s3x_O8rQjXanUYGHlpQ&usqp=CAU" class="nav__image" alt="Woman with arms crossed in a top and jeans" />
   </a>

 </nav>

@endsection
